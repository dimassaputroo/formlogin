# VB.NET
simple example of a login &amp; registration form connected to a SQL server database.
